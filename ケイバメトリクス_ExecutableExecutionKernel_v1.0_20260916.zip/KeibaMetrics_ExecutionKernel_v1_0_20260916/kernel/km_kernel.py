#!/usr/bin/env python3
import argparse, hashlib, json, os, sys, datetime, subprocess, shlex
from pathlib import Path

VERSION = "KM-EXEC-KERNEL-v1.0-20260916"
REQUIRED_INDICES = [
    "SRI","HPI-L","CFIg-L","RFIg-L","BVIg-L","JTI-L","CSI-L","BWI-L","DCR",
    "EVI/CEV","NCI/DRS/URP/HCS","PRI","OPI-V","TPI-L","ZAI-WIN/ZAI-PLACE",
    "SRI-L","T3I-L","F3S-L","WCI","GCI","W-AKI","P2-AKI","P3-AKI","ASI","RSI"
]
VALID_INDEX_STATUS = {"CALCULATED","MISSING-WITH-REASON","NOT-APPLICABLE-WITH-REASON"}
PLACEHOLDERS = {"TBD","PENDING","TODO","TEMP","NOT-YET-CALCULATED","NOT-YET-GENERATED","LATER","UNKNOWN-TBD"}
ARTIFACTS = {
    "authority": "00_authority_snapshot.json",
    "universe": "01_runner_universe.json",
    "indices": "02_required_indices.json",
    "static": "03_static_prediction.json",
    "krs_plan": "04_krs_plan.json",
    "krs_receipt": "05_krs_run_receipt.json",
    "krs_output": "06_krs_output.json",
    "fpp": "07_final_prediction_package.json",
    "transport": "08_ticket_transport.json",
    "ticket": "09_final_ticket.json",
    "result": "10_official_result.json",
    "settlement": "11_settlement.json",
    "learning": "12_learning_event.json",
}

def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def load(p): return json.loads(Path(p).read_text(encoding="utf-8"))
def save(p,obj):
    p=Path(p); p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding="utf-8")
def sha256_file(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for c in iter(lambda:f.read(1024*1024),b''): h.update(c)
    return h.hexdigest()
def wsfile(ws,key): return Path(ws)/ARTIFACTS[key]
def exists(ws,key): return wsfile(ws,key).is_file()
def ahash(ws,key): return sha256_file(wsfile(ws,key)) if exists(ws,key) else None

def init_ws(args):
    ws=Path(args.workspace); ws.mkdir(parents=True,exist_ok=True); (ws/'receipts').mkdir(exist_ok=True)
    authority={
        "kernel":VERSION,
        "race_id":args.race_id,
        "venue":args.venue,
        "production":args.production,
        "family_profile":args.family_profile,
        "active_hotfix":args.active_hotfix,
        "venue_canon":args.venue_canon,
        "krs_required":args.krs_required,
        "created_at":now(),
        "authority_status":"PINNED-FOR-RACE"
    }
    save(wsfile(ws,"authority"),authority)
    # no fake stage artifacts are created; missing means not done.
    print(json.dumps({"status":"INITIALIZED","workspace":str(ws),"authority_sha256":ahash(ws,"authority")},ensure_ascii=False,indent=2))


def universe_ids(u):
    runners=u.get("runners") or []
    out=[]
    for r in runners:
        rid=str(r.get("number") if isinstance(r,dict) else r).strip()
        if rid: out.append(rid)
    return out

def ranking_ids(obj,key="ranking_all"):
    arr=obj.get(key) or []
    out=[]
    for x in arr:
        if isinstance(x,dict): rid=x.get("number") or x.get("runner") or x.get("horse_number")
        else: rid=x
        if rid is not None: out.append(str(rid))
    return out

def check_authority(ws,e,w):
    if not exists(ws,"authority"): e.append("AUTHORITY_SNAPSHOT_MISSING"); return None
    a=load(wsfile(ws,"authority"))
    for k in ("race_id","venue","production","venue_canon","family_profile","active_hotfix"):
        if not str(a.get(k) or '').strip(): e.append(f"AUTHORITY_FIELD_MISSING:{k}")
    return a

def check_universe(ws,e,w):
    if not exists(ws,"universe"): e.append("RUNNER_UNIVERSE_ARTIFACT_MISSING"); return []
    u=load(wsfile(ws,"universe")); ids=universe_ids(u)
    if not ids: e.append("RUNNER_UNIVERSE_EMPTY")
    if len(ids)!=len(set(ids)): e.append("RUNNER_UNIVERSE_DUPLICATE_NUMBER")
    if not u.get("frozen_at"): e.append("RUNNER_UNIVERSE_FREEZE_TIMESTAMP_MISSING")
    return ids

def check_indices(ws,e,w):
    if not exists(ws,"indices"): e.append("REQUIRED_INDICES_ARTIFACT_MISSING"); return
    d=load(wsfile(ws,"indices")); inds=d.get("indices") if isinstance(d,dict) else None
    if not isinstance(inds,dict): e.append("REQUIRED_INDICES_NOT_OBJECT"); return
    for k in REQUIRED_INDICES:
        if k not in inds: e.append(f"SILENT_INDEX_OMISSION:{k}"); continue
        rec=inds.get(k) or {}; st=rec.get("status"); reason=str(rec.get("reason") or '').strip()
        if st not in VALID_INDEX_STATUS: e.append(f"INVALID_INDEX_STATUS:{k}:{st}")
        if st!="CALCULATED":
            if not reason: e.append(f"MISSING_INDEX_REASON:{k}")
            elif reason.upper() in PLACEHOLDERS: e.append(f"PLACEHOLDER_INDEX_REASON:{k}:{reason}")
        if st=="CALCULATED" and rec.get("value") is None and not rec.get("artifact_ref"):
            e.append(f"CALCULATED_INDEX_WITHOUT_VALUE_OR_ARTIFACT:{k}")
    calc=sum(1 for k in REQUIRED_INDICES if (inds.get(k) or {}).get("status")=="CALCULATED")
    disp=sum(1 for k in REQUIRED_INDICES if (inds.get(k) or {}).get("status") in VALID_INDEX_STATUS and ((inds.get(k) or {}).get("status")=="CALCULATED" or (str((inds.get(k) or {}).get("reason") or '').strip() and str((inds.get(k) or {}).get("reason") or '').strip().upper() not in PLACEHOLDERS)))
    dcalc=d.get("actual_calculation_completion")
    ddisp=d.get("disposition_completion")
    expected_calc=round(calc/len(REQUIRED_INDICES),6); expected_disp=round(disp/len(REQUIRED_INDICES),6)
    if dcalc is not None and abs(float(dcalc)-expected_calc)>1e-6: e.append("ACTUAL_CALCULATION_COMPLETION_MISMATCH")
    if ddisp is not None and abs(float(ddisp)-expected_disp)>1e-6: e.append("INDEX_DISPOSITION_COMPLETION_MISMATCH")

def check_prediction(ws,key,ids,e,w):
    if not exists(ws,key): e.append(f"{key.upper()}_ARTIFACT_MISSING"); return
    p=load(wsfile(ws,key)); ranks=ranking_ids(p)
    if not p.get("frozen_at"): e.append(f"{key.upper()}_FREEZE_TIMESTAMP_MISSING")
    covered=set(ranks)
    unr={str(x) for x in (p.get("unranked_with_reason") or {}).keys()}
    missing=set(ids)-covered-unr
    extra=covered-set(ids)
    if missing: e.append(f"{key.upper()}_RUNNERS_UNACCOUNTED:"+",".join(sorted(missing)))
    if extra: e.append(f"{key.upper()}_UNKNOWN_RUNNERS:"+",".join(sorted(extra)))
    if len(ranks)!=len(set(ranks)): e.append(f"{key.upper()}_DUPLICATE_RANKED_RUNNER")

def krs_executable(plan):
    return bool(plan.get("required") and plan.get("engine_available") and plan.get("minimum_input_executable") and plan.get("deadline_available"))
def check_krs_final(ws,e,w):
    if not exists(ws,"krs_plan"): e.append("KRS_PLAN_MISSING"); return
    plan=load(wsfile(ws,"krs_plan")); ex=krs_executable(plan)
    if ex and not exists(ws,"krs_receipt"):
        e.append("KRS_EXECUTABLE_BUT_RUN_RECEIPT_MISSING"); return
    if not exists(ws,"krs_receipt"):
        cause=str(plan.get("nonexecution_cause") or '').strip()
        if plan.get("required") and not cause: e.append("KRS_REQUIRED_NONEXECUTION_CAUSE_MISSING")
        return
    r=load(wsfile(ws,"krs_receipt"))
    if not r.get("execution_attempted"): e.append("KRS_RUN_RECEIPT_WITHOUT_ATTEMPT")
    if r.get("execution_completed"):
        if not exists(ws,"krs_output"): e.append("KRS_COMPLETED_WITHOUT_OUTPUT_ARTIFACT")
        elif r.get("output_sha256") and r.get("output_sha256")!=ahash(ws,"krs_output"): e.append("KRS_OUTPUT_HASH_MISMATCH")
    else:
        if not str(r.get("failure_cause") or '').strip(): e.append("KRS_INCOMPLETE_WITHOUT_FAILURE_CAUSE")

def material_ids(fpp):
    return {str(x.get("structure_id")) for x in (fpp.get("material_structures") or []) if x.get("structure_id")}
def check_transport_ticket(ws,e,w):
    if not exists(ws,"fpp"): return
    fpp=load(wsfile(ws,"fpp")); mids=material_ids(fpp)
    if not exists(ws,"transport"): e.append("TICKET_TRANSPORT_ARTIFACT_MISSING"); return
    t=load(wsfile(ws,"transport")); recs=t.get("records") or []
    by={str(r.get("structure_id")):r for r in recs if r.get("structure_id")}
    for sid in sorted(mids):
        if sid not in by: e.append(f"MATERIAL_STRUCTURE_NOT_TRACED:{sid}"); continue
        r=by[sid]; gen=r.get("candidate_generated")
        if not isinstance(gen,bool): e.append(f"TRANSPORT_GENERATION_STATUS_MISSING:{sid}")
        elif not gen and not str(r.get("non_generation_reason") or '').strip(): e.append(f"TRANSPORT_NON_GENERATION_REASON_MISSING:{sid}")
        elif gen:
            sel=r.get("selected")
            if not isinstance(sel,bool): e.append(f"TRANSPORT_SELECTION_STATUS_MISSING:{sid}")
            elif not sel and not str(r.get("nonselection_reason") or '').strip(): e.append(f"TRANSPORT_NONSELECTION_REASON_MISSING:{sid}")
    if not exists(ws,"ticket"): e.append("FINAL_TICKET_ARTIFACT_MISSING"); return
    ft=load(wsfile(ws,"ticket"))
    if not ft.get("frozen_at"): e.append("FINAL_TICKET_FREEZE_TIMESTAMP_MISSING")
    if not ft.get("finalized"): e.append("FINAL_TICKET_NOT_FINALIZED")
    tickets=ft.get("tickets") or []
    if ft.get("finalized") and not tickets and not ft.get("no_bet"):
        e.append("FINALIZED_WITHOUT_TICKETS_OR_NO_BET")
    if tickets:
        stakes=[]
        for i,x in enumerate(tickets):
            s=x.get("stake")
            if not isinstance(s,(int,float)) or s<0: e.append(f"INVALID_TICKET_STAKE:{i}")
            else: stakes.append(s)
        total=sum(stakes)
        if ft.get("total_investment") is None or abs(float(ft.get("total_investment"))-total)>1e-6:
            e.append("FINAL_TICKET_TOTAL_INVESTMENT_MISMATCH")

def validate(ws,phase):
    ws=Path(ws); phase=phase.upper(); e=[]; w=[]
    a=check_authority(ws,e,w); ids=check_universe(ws,e,w); check_indices(ws,e,w)
    check_prediction(ws,"static",ids,e,w)
    if phase in {"FINAL","RESULT"}:
        check_krs_final(ws,e,w); check_prediction(ws,"fpp",ids,e,w); check_transport_ticket(ws,e,w)
    if phase=="RESULT":
        if not exists(ws,"result"): e.append("OFFICIAL_RESULT_ARTIFACT_MISSING")
        else:
            r=load(wsfile(ws,"result")); order=[str(x) for x in (r.get("official_order") or [])]
            if not order: e.append("OFFICIAL_RESULT_ORDER_MISSING")
            if not r.get("official_at"): e.append("OFFICIAL_RESULT_TIMESTAMP_MISSING")
        if not exists(ws,"settlement"): e.append("SETTLEMENT_ARTIFACT_MISSING")
        else:
            s=load(wsfile(ws,"settlement")); st=s.get("status")
            if st not in {"SETTLED","PENDING","NOT-APPLICABLE"}: e.append("INVALID_SETTLEMENT_STATUS")
            if st=="PENDING" and s.get("frozen_return") is not None: e.append("PENDING_SETTLEMENT_MUST_NOT_HAVE_RETURN")
            if st=="SETTLED" and s.get("frozen_return") is None: e.append("SETTLED_FROZEN_RETURN_MISSING")
    return e,w

def hashes_for_phase(ws,phase):
    keys=["authority","universe","indices","static"]
    if phase in {"FINAL","RESULT"}: keys += ["krs_plan","krs_receipt","krs_output","fpp","transport","ticket"]
    if phase=="RESULT": keys += ["result","settlement","learning"]
    return {ARTIFACTS[k]:ahash(ws,k) for k in keys if exists(ws,k)}

def seal(ws,phase):
    e,w=validate(ws,phase); out={"kernel":VERSION,"phase":phase.upper(),"status":"PASS" if not e else "FAIL","errors":e,"warnings":w,"checked_at":now(),"artifact_hashes":hashes_for_phase(ws,phase)}
    if not e:
        rp=Path(ws)/'receipts'/f'{phase.upper()}_RECEIPT.json'; save(rp,out); out['receipt_path']=str(rp); out['receipt_sha256']=sha256_file(rp)
    print(json.dumps(out,ensure_ascii=False,indent=2)); return 0 if not e else 2

def status(ws):
    phases={p:(Path(ws)/'receipts'/f'{p}_RECEIPT.json').is_file() for p in ("PRE_KRS","FINAL","RESULT")}
    present={k:exists(ws,k) for k in ARTIFACTS}
    if not present['universe']: nxt='CREATE_RUNNER_UNIVERSE'
    elif not present['indices']: nxt='CALCULATE_OR_DISPOSE_ALL_REQUIRED_INDICES'
    elif not present['static']: nxt='FREEZE_STATIC_PREDICTION'
    elif not phases['PRE_KRS']: nxt='SEAL_PRE_KRS'
    elif not present['krs_plan']: nxt='CREATE_KRS_PLAN_AND_DISCOVER_ENGINE'
    elif not present['fpp']: nxt='RUN_KRS_IF_REQUIRED_THEN_FREEZE_FINAL_PREDICTION'
    elif not present['transport']: nxt='TRACE_FPP_TO_TICKET_CANDIDATES'
    elif not present['ticket']: nxt='FREEZE_FINAL_TICKET'
    elif not phases['FINAL']: nxt='SEAL_FINAL'
    elif not present['result']: nxt='WAIT_FOR_AND_RECORD_OFFICIAL_RESULT'
    elif not present['settlement']: nxt='RECORD_SETTLEMENT_STATUS'
    elif not phases['RESULT']: nxt='CREATE_LEARNING_EVENT_AND_SEAL_RESULT'
    else: nxt='COMPLETE'
    print(json.dumps({"kernel":VERSION,"workspace":str(ws),"phase_receipts":phases,"artifacts":present,"next_action":nxt},ensure_ascii=False,indent=2))

def discover_engine(roots):
    hits=[]
    pats=("*KRS*Engine*.py","*KRS-Engine*.py","*KRS_ENGINE*.py")
    seen=set()
    for root in roots:
        p=Path(root)
        if not p.exists(): continue
        for pat in pats:
            for f in p.rglob(pat):
                if f.is_file() and str(f) not in seen:
                    seen.add(str(f)); hits.append({"path":str(f),"sha256":sha256_file(f),"size":f.stat().st_size})
    print(json.dumps({"found":bool(hits),"engines":hits},ensure_ascii=False,indent=2)); return 0 if hits else 3

def run_external(args):
    ws=Path(args.workspace); cmd=shlex.split(args.command)
    started=now(); proc=subprocess.run(cmd,capture_output=True,text=True,cwd=args.cwd or None,timeout=args.timeout)
    log={"execution_attempted":True,"execution_completed":proc.returncode==0,"returncode":proc.returncode,"started_at":started,"finished_at":now(),"command":cmd,"stdout_tail":proc.stdout[-4000:],"stderr_tail":proc.stderr[-4000:]}
    if args.output and Path(args.output).is_file():
        dst=wsfile(ws,"krs_output"); dst.write_bytes(Path(args.output).read_bytes()); log['output_sha256']=sha256_file(dst)
    else: log['failure_cause']=None if proc.returncode==0 else "ENGINE_NONZERO_EXIT"
    save(wsfile(ws,"krs_receipt"),log)
    print(json.dumps(log,ensure_ascii=False,indent=2)); return proc.returncode

def make_learning(ws,ledger_path=None):
    ws=Path(ws)
    if not (exists(ws,"static") and exists(ws,"result")): raise SystemExit("static/result missing")
    st=load(wsfile(ws,"static")); res=load(wsfile(ws,"result")); order=[str(x) for x in res.get('official_order',[])]
    winner=order[0] if order else None
    sids=ranking_ids(st)
    n=len(universe_ids(load(wsfile(ws,'universe'))))
    def pos(arr,x): return arr.index(x)+1 if x in arr else n+1
    ev={"kernel":VERSION,"race_id":load(wsfile(ws,'authority')).get('race_id'),"created_at":now(),"winner":winner,"static_winner_rank":pos(sids,winner) if winner else None}
    if exists(ws,"krs_output"):
        ko=load(wsfile(ws,"krs_output")); kids=ranking_ids(ko)
        ev['krs_winner_rank']=pos(kids,winner) if winner else None
        ev['winner_rank_gain']=ev['static_winner_rank']-ev['krs_winner_rank'] if winner else None
        k=int((load(wsfile(ws,'krs_plan')).get('primary_k') or 3)) if exists(ws,'krs_plan') else 3
        ev['unique_rescue']=bool(ev['static_winner_rank']>k and ev['krs_winner_rank']<=k)
        ev['unique_harm']=bool(ev['static_winner_rank']<=k and ev['krs_winner_rank']>k)
    if exists(ws,"ticket") and exists(ws,"settlement"):
        t=load(wsfile(ws,'ticket')); se=load(wsfile(ws,'settlement'))
        if se.get('status')=='SETTLED' and t.get('total_investment') is not None:
            stake=float(t.get('total_investment') or 0); ret=float(se.get('frozen_return') or 0)
            ev['frozen_recommendation_pfs']=None if stake<=0 else ret/stake
    save(wsfile(ws,'learning'),ev)
    if ledger_path:
        lp=Path(ledger_path); ledger=load(lp) if lp.exists() else {"kernel":VERSION,"events":[]}
        events=ledger.setdefault('events',[])
        if any(x.get('race_id')==ev['race_id'] for x in events): raise SystemExit("duplicate race_id in ledger")
        events.append(ev); save(lp,ledger)
    print(json.dumps(ev,ensure_ascii=False,indent=2))

def main():
    ap=argparse.ArgumentParser(); sub=ap.add_subparsers(dest='cmd',required=True)
    p=sub.add_parser('init'); p.add_argument('workspace'); p.add_argument('--race-id',required=True); p.add_argument('--venue',required=True); p.add_argument('--venue-canon',required=True); p.add_argument('--production',default='KM-LOCAL-RENDERED-INTEGRITY-20260827-R3'); p.add_argument('--family-profile',default='KM-FAMILY-CANONICAL-RATIONALIZATION-20260916-R3-HF1'); p.add_argument('--active-hotfix',default='KM-LOCAL-R3-ASTRA-CORRECTIVE-REPAIR-20260916-HF1'); p.add_argument('--krs-required',action=argparse.BooleanOptionalAction,default=True)
    p=sub.add_parser('seal'); p.add_argument('workspace'); p.add_argument('phase',choices=['PRE_KRS','FINAL','RESULT'])
    p=sub.add_parser('status'); p.add_argument('workspace')
    p=sub.add_parser('discover-engine'); p.add_argument('roots',nargs='+')
    p=sub.add_parser('run-external'); p.add_argument('workspace'); p.add_argument('--command',required=True); p.add_argument('--output'); p.add_argument('--cwd'); p.add_argument('--timeout',type=int,default=120)
    p=sub.add_parser('learn'); p.add_argument('workspace'); p.add_argument('--ledger')
    args=ap.parse_args()
    if args.cmd=='init': init_ws(args)
    elif args.cmd=='seal': sys.exit(seal(args.workspace,args.phase))
    elif args.cmd=='status': status(args.workspace)
    elif args.cmd=='discover-engine': sys.exit(discover_engine(args.roots))
    elif args.cmd=='run-external': sys.exit(run_external(args))
    elif args.cmd=='learn': make_learning(args.workspace,args.ledger)
if __name__=='__main__': main()
