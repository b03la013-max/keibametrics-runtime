#!/usr/bin/env python3
import json, sys
from pathlib import Path

def load(p): return json.loads(Path(p).read_text(encoding='utf-8'))
def main(root):
    root=Path(root); rows=[]
    for ws in sorted([p for p in root.iterdir() if p.is_dir()]):
        ap=ws/'00_authority_snapshot.json'; tp=ws/'09_final_ticket.json'; sp=ws/'11_settlement.json'; rp=ws/'receipts/FINAL_RECEIPT.json'
        if not ap.exists(): continue
        a=load(ap); row={'race_id':a.get('race_id'),'venue':a.get('venue'),'final_receipt':rp.exists(),'settlement':'UNKNOWN','investment':None,'return':None,'pfs':None}
        if tp.exists(): row['investment']=load(tp).get('total_investment')
        if sp.exists():
            s=load(sp); row['settlement']=s.get('status')
            if s.get('status')=='SETTLED':
                row['return']=s.get('frozen_return')
                if row['investment'] not in (None,0): row['pfs']=float(row['return'] or 0)/float(row['investment'])
        rows.append(row)
    settled=[r for r in rows if r['settlement']=='SETTLED' and r['investment'] is not None]
    invest=sum(float(r['investment'] or 0) for r in settled); ret=sum(float(r['return'] or 0) for r in settled)
    out={'races':rows,'settled_races':len(settled),'pending_races':sum(r['settlement']=='PENDING' for r in rows),'settled_investment':invest,'settled_return':ret,'settled_pfs':None if invest<=0 else ret/invest,'finalization_rate':None if not rows else sum(r['final_receipt'] for r in rows)/len(rows)}
    print(json.dumps(out,ensure_ascii=False,indent=2))
if __name__=='__main__': main(sys.argv[1])
