KeibaMetrics Executable Execution Kernel v1.0
Profile: KM-EXEC-KERNEL-v1.0-20260916

Purpose
- Prose compliance is not trusted.
- A race is not allowed to be called FORMAL-FULL merely because ChatGPT says it was done.
- PRE_KRS / FINAL / RESULT completion is proven by artifact existence + deterministic validation + SHA256 receipt.

Absolute rule
1. No PRE_KRS receipt -> Static/indices execution is not proven complete.
2. No FINAL receipt -> "FINAL-PASS", "完全フル規格完了", or a completed Final Bet may not be claimed.
3. KRS "EXECUTED" requires run receipt and, when completed, a real output artifact hash.
4. Missing required indices cannot disappear silently.
5. Result/settlement cannot rewrite pre-race artifacts.
6. Pending settlement is never zero return.
7. RESULT creates a learning event for the next unknown race.

The model may reason. The Kernel decides whether the execution claim is true.
