#!/usr/bin/env python3
import json, tempfile, subprocess, sys, shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; K=ROOT/'kernel/km_kernel.py'
REQ=["SRI","HPI-L","CFIg-L","RFIg-L","BVIg-L","JTI-L","CSI-L","BWI-L","DCR","EVI/CEV","NCI/DRS/URP/HCS","PRI","OPI-V","TPI-L","ZAI-WIN/ZAI-PLACE","SRI-L","T3I-L","F3S-L","WCI","GCI","W-AKI","P2-AKI","P3-AKI","ASI","RSI"]
def run(*a): return subprocess.run([sys.executable,str(K),*map(str,a)],capture_output=True,text=True)
def wr(p,o): Path(p).write_text(json.dumps(o,ensure_ascii=False,indent=2),encoding='utf-8')
def base(ws):
    run('init',ws,'--race-id','TEST-20260916-R01','--venue','TEST','--venue-canon','TEST-v1')
    wr(Path(ws)/'01_runner_universe.json',{'frozen_at':'t','runners':[{'number':1},{'number':2},{'number':3}]})
    inds={k:{'status':'CALCULATED','value':1.0} for k in REQ}
    wr(Path(ws)/'02_required_indices.json',{'disposition_completion':1.0,'actual_calculation_completion':1.0,'indices':inds})
    wr(Path(ws)/'03_static_prediction.json',{'frozen_at':'t','ranking_all':[1,2,3]})

def main():
    results=[]
    td=tempfile.mkdtemp()
    try:
        # 1 silent omission fails
        ws=Path(td)/'a'; base(ws); d=json.loads((ws/'02_required_indices.json').read_text()); del d['indices']['SRI']; wr(ws/'02_required_indices.json',d)
        results.append(('silent_omission_fails',run('seal',ws,'PRE_KRS').returncode!=0))
        # 2 complete pre-krs passes
        ws=Path(td)/'b'; base(ws); results.append(('complete_prekrs_passes',run('seal',ws,'PRE_KRS').returncode==0))
        # 3 executable KRS missing receipt fails final
        wr(ws/'04_krs_plan.json',{'required':True,'engine_available':True,'minimum_input_executable':True,'deadline_available':True,'primary_k':3})
        wr(ws/'07_final_prediction_package.json',{'frozen_at':'t','ranking_all':[1,2,3],'material_structures':[]})
        wr(ws/'08_ticket_transport.json',{'records':[]})
        wr(ws/'09_final_ticket.json',{'frozen_at':'t','finalized':True,'no_bet':True,'tickets':[],'total_investment':0})
        results.append(('krs_missing_receipt_fails',run('seal',ws,'FINAL').returncode!=0))
        # 4 complete final passes
        wr(ws/'05_krs_run_receipt.json',{'execution_attempted':True,'execution_completed':True,'returncode':0})
        wr(ws/'06_krs_output.json',{'ranking_all':[1,3,2]})
        # inject output hash via tool helper not accessible; receipt hash optional, existence verified
        results.append(('complete_final_passes',run('seal',ws,'FINAL').returncode==0))
        # 5 pending settlement does not become zero
        wr(ws/'10_official_result.json',{'official_at':'t','official_order':[1,2,3]}); wr(ws/'11_settlement.json',{'status':'PENDING','frozen_return':None})
        run('learn',ws)
        results.append(('pending_result_passes_without_zero',run('seal',ws,'RESULT').returncode==0 and json.loads((ws/'11_settlement.json').read_text())['frozen_return'] is None))
        # 6 settled zero is valid
        wr(ws/'11_settlement.json',{'status':'SETTLED','frozen_return':0}); run('learn',ws)
        results.append(('settled_zero_valid',run('seal',ws,'RESULT').returncode==0))
        # 7 placeholder reason fails
        ws=Path(td)/'c'; base(ws); d=json.loads((ws/'02_required_indices.json').read_text()); d['indices']['SRI']={'status':'MISSING-WITH-REASON','reason':'TBD'}; d['actual_calculation_completion']=24/25; wr(ws/'02_required_indices.json',d)
        results.append(('placeholder_reason_fails',run('seal',ws,'PRE_KRS').returncode!=0))
        # 8 no artifact means no self-certification
        ws=Path(td)/'d'; run('init',ws,'--race-id','X','--venue','X','--venue-canon','X-v1')
        results.append(('no_artifacts_no_pass',run('seal',ws,'PRE_KRS').returncode!=0))
        out={'passed':sum(v for _,v in results),'total':len(results),'tests':[{'name':n,'pass':v} for n,v in results]}
        print(json.dumps(out,indent=2)); return 0 if all(v for _,v in results) else 2
    finally: shutil.rmtree(td)
if __name__=='__main__': raise SystemExit(main())
